<template >
    <div>
   
    </div>
</template>
<script>
export default {
    name:"ViewOrderId",
    props:{
        viewObj:Object
    }
}
</script>
<style lang="">
    
</style>