<template>
    <div class="router-view-container">
        <SalesHeader/>
    </div>
</template>
<script>
import SalesHeader from "@/components/SalesHeader.vue";
export default {
    name:"Sales",
    components:{
        SalesHeader
    }
}
</script>
<style lang="">
    
</style>