<template>
  
<MainHeader/>
   
</template>

<script>
import MainHeader from "@/components/MainHeader.vue";
export default {
  name: 'Home',
  components: {
   MainHeader
  }
}
</script>
